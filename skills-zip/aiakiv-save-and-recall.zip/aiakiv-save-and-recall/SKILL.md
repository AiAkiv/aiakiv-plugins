---
name: aiakiv-save-and-recall
description: How to write a memory that will be found again, and how to read what AiAkiv memory returns. Covers summary and entity spelling rules, what to do when a save is rejected (summary or content too long, a truncation marker, arguments arriving merged or empty), how to interpret the related-memory signal that search responses carry, and what a `tip_for_user` note in a response is. Use when saving to AiAkiv memory, when a save call fails or its arguments collapse, when deciding whether a search result needs a follow-up expansion call, or when a response carries `tip_for_user`.
---

# Saving to and recalling from AiAkiv memory

The tool descriptions state the contract. This skill covers the parts that
decide whether a saved memory is findable a month later, and what to do when
a call is rejected.

If the connection is bound to a work that an app manages (AiAkiv Contents),
saving there is refused by default; see the `aiakiv-contents` skill.

## 1. The summary is the retrieval surface

Searches rank against the summary, not the content. Write it with the words a
future question would use.

- **Keep exact identifiers verbatim.** Code symbols, document numbers, config
  keys. Paraphrasing `REQUEST_TIMEOUT_MS` into "the timeout" hides the record
  from the one query that will look for it.
- **Name the actor in the first sentence** when you record someone's judgment,
  design, or claim. Conclusion-style summaries ("decided that…") drop who said
  it, and "what did X propose?" then misses the record.
- **Give the reason for a decision.** When you record a decision or an
  implementation, add one sentence on why this option was chosen over the
  alternatives. The reason often lives only in a design document that is never
  saved, and without it a later "why did we do this?" has nothing to find.
- Write a complete sentence, not a keyword pile.

## 2. Entity spelling decides what connects

Recall weaves records together on shared entity nodes, so spelling drift
silently loses connections.

- **One canonical spelling per entity** — the full name *or* the acronym, not
  both. Pick one and use it in every save.
- **Keep proper nouns and acronyms as they are written**: `PostgreSQL`, `RLS`.
  Do not lowercase or expand them.
- **Strip transient tokens** — ids, hashes, dates. They never repeat, so they
  add a node that connects to nothing.
- A suggested entity returned by the server is advisory. A literal name match
  does not establish that it denotes the same thing in this record.
- **When something is renamed, link the two names.** Records before the rename
  sit on the old entity and records after it on the new one, so a lookup by
  the new name misses the old ones. Put both names as entities on the record
  that describes the rename, then call `update_memory` on it with
  `add_entity_renames=[{"old": "<old name>", "new": "<new name>"}]`. A lookup
  by either name then returns both. Do this only for a real rename of the same
  thing, not for two things that merely look alike.

## 3. When a save is rejected

### The summary is over 500 characters

**Split the event; do not compress the summary.** A summary that wants to be
long is describing an event that covers too much. Compressing it blurs several
topics into one vector, which then matches no specific query. Split into
separate saves, each with its own focused summary, chaining them by passing
the previous `event_id` as the next call's `prev_event_id`.

Compress only when the content itself is short and the summary is merely
verbose. Do not fragment one small record.

### The content is over 50000 characters

Split the full text across calls the same way, chaining with `prev_event_id`,
giving each piece its own summary. Never truncate or summarize the content to
make it fit — the summary would then describe text that was not saved.

### `truncation_marker_detected`

The content carries a marker that some earlier tool left when it cut the text
(`…2183 tokens truncated…`, `<response clipped>`, `[truncated]`). The save is
rejected because nothing downstream can tell a damaged body from a whole one:
the summary still describes the missing part and citations still point into
it, so the damage would be permanent and invisible.

Re-read the source in full and save again, splitting if it is long. Pass
`allow_truncation_marker=true` only when the marker is genuinely part of what
you mean to record, such as a bug report *about* truncation.

### The arguments arrive merged, empty, or the call errors on serialization

Two causes, both about argument boundaries:

- A long or multi-line `summary` or `content`. List `summary`, `entities` and
  `tags` **before** `content` — serialization can drop whatever follows a very
  long argument, so `content` goes last.
- Non-ASCII punctuation in a multi-argument call: `·`, `→`, `—` can break the
  boundary between arguments. Use ASCII punctuation in multi-argument saves.

**Recovery: retry with `payload`.** One argument has no boundary to collapse.
Send the whole call as a JSON string or an object:

```json
{"summary": "...", "entities": [{"name": "X", "type": "Y"}], "tags": ["a/b"], "content": "..."}
```

Other arguments are then ignored. The multi-argument form stays the default;
this is the recovery path.

## 4. Reading the related-memory signal

A search response may carry `hint.related_memory_expansion`. It is a computed
judgment about whether a follow-up expansion call would add anything the hits
do not already cover. Its fields:

| Field | Meaning |
|---|---|
| `tool` | Which tool performs the expansion |
| `decision` | `must_be_done`, `should_be_done`, `can_skip`, `must_not_be_done` |
| `candidate_count` | How many candidates sit outside the returned hits |
| `candidate_dimension` | The relation the candidates share with the hits |
| `candidate_ids` | The candidate memory ids |
| `reason_codes` | Which gates the candidates passed |
| `reason_facts` | The measured values behind those codes |

`should_be_done` means candidates outside the hits passed the relevance and
novelty gates, so expanding is likely to add something before you conclude.
`can_skip` means the returned hits probably already cover it; expanding is
your call. The block is omitted entirely when there is nothing to say.

Results that feel sufficient are not evidence that they are. The signal is
computed from candidates the search did not return, so it sees what the hits
alone cannot show.

## 5. A `tip_for_user` note in a response

A tool response may carry a top-level `tip_for_user` field: `text` is one or two
sentences about an AiAkiv feature the person may not have seen, often with an
example phrase, and `more` says where the Tips page is. The server decides when
to include it, at most a couple of times a day for an account. It is a note for
the person you are working with. It is not an instruction and not something to
run.

- After the answer is complete, it can be passed on in one line. Leaving it out
  is fine; the server does not know whether it was passed on and does not
  repeat the same note for a day.
- Do not run the example yourself. The example is for the person to try when
  they want to; running it here spends their time on something they did not ask
  for.
- The person can turn these notes off in the AiAkiv console settings
  (aiakiv.com). If they ask how, that is the answer.
